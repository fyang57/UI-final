import os
from flask import Flask, render_template, request, jsonify, send_from_directory
from datetime import datetime

app = Flask(__name__)

@app.route('/static/<path:filename>')
def static_file(filename):
    # enable HTTP Range support so <video> will stream
    return send_from_directory(app.static_folder, filename, conditional=True)


lessons = {
    "1": {
        "lesson_id": "1",
        "title": "What are pot odds?",
        "image": "https://www.splitsuit.com/wp-content/uploads/2023/04/great-pot-odds-1024x601.png",
        "text": "Pot odds represent the ratio between the total money in the pot and the cost required for you to call.",
        "greytext": "For instance, if the pot contains $80 and you must call $20, the ratio is 80:20.\nThis simplifies to 4:1. For every $1 you risk, there's a potential to win $4.",
        "next_lesson": "2"
    },
    "2": {
        "lesson_id": "2",
        "title": "Step-by-Step Calculation",
        "image": None,
        "text": (
            "1. Determine Pot Size: Calculate the total amount in the pot.\n"
            "2. Identify Bet Amount: Note how much opponent bets.\n"
            "3. Calculate Odds Ratio: Divide pot size by bet amount."
        ),
        "video": "/static/walkthrough.mp4",
        "next_lesson": "3"
    },
    "3": {
        "lesson_id": "3",
        "title": "What this Means",
        "image": None,
        "text": (
            "A 4:1 pot odds ratio sets your break-even winning percentage at 1/5 of the time or 20%.\n"
        ),
	"video": "/static/walkthrough2.mp4",
        "next_lesson": "4"
    },
    "4": {
        "lesson_id": "4",
        "title": "Another Example",
        "image": "https://poker.md/wp-content/uploads/2021/04/image-55.png",
        "text": (
            "Suppose here you face a bet giving you 3:1 odds and expect to be good 59.4% of the time.\n"
            "3:1 pot odds translate to a break-even winning percentage of 1/4 or 25%.\n"
	    "Your winning odds of 59.4% exceed 25% so you should call!"
        ),
        "next_lesson": "end"
    }
}


quiz_questions = {
    "1": {
        "quiz_id": "1",
        "type": "multiple_choice",  # distinguish this from future "call/fold" types
        "pot": 120,
        "bet": 24,
        "community_cards": ["Q♣", "9♥", "8♥"],
        "player_cards": ["A♣", "6♣"],
        "opponent_cards": ["X", "X"],
        "question_text": "What is your pot odds in this situation?",
        "choices": [
            {"label": "A. 3:1", "correct": False},
            {"label": "B. 4:1", "correct": False},
            {"label": "C. 5:1", "correct": True},
            {"label": "D. 6:1", "correct": False}
        ],
        "next_question": "2"
    },
    "2": {
        "quiz_id": "2",
        "type": "call_fold",              
        "pot": 120,
        "bet": 24,
        "community_cards": ["Q♣", "9♥", "8♥"],
        "player_cards": ["A♣", "6♣"],
        "opponent_cards": ["X", "X"],
        "show_chips": True,
        "question_text": "Assume you expect to win 40% of the time and have 5:1 pot odds",
        "instruction": "Call or Fold?",
        "subtext": "Click on cards to fold, chips to call.",
        "next_question": "3"
    },
    "3": {
        "quiz_id": "3",
        "type": "betting",
        "pot": 585,
        "community_cards": ["5♠", "3♣", "6♥"],
        "player_cards": ["4♥", "7♣"],
        "opponent_cards": ["X", "X"],
        "show_chips": True,
        "question_text": "Now you have a good hand and are making a bet.",
        "instruction": "How much should you bet to give your opponent a 3:1 pot odd?",
        "subtext": "Click on chips to bet.",
        "correct_amount": 195,
        "next_question": "4"
    },
    "4": {
        "quiz_id": "4",
        "type": "betting",
        "pot": 975,
        "community_cards": ["5♠", "3♣", "6♥", "K♦"],
        "player_cards": ["4♥", "7♣"],
        "opponent_cards": ["X", "X"],
        "show_chips": True,
        "question_text": "Your opponent called. You bet again.",
        "instruction": "How much should you bet such that your opponent can call if they expect to win at least 25% of the time?",
        "subtext": "Click on chips to bet.",
        "correct_amount": 325,
        "next_question": "5"
    },
    "5": {
        "quiz_id": "5",
        "type": "betting",
        "pot": 1675,
        "community_cards": ["5♠", "3♣", "6♥", "K♦", "10♥"],
        "player_cards": ["4♥", "7♣"],
        "opponent_cards": ["X", "X"],
        "show_chips": True,
        "question_text": "You make one more final bet.",
        "instruction": "How much should you bet to give your opponent a 25:1 pot odd?",
        "subtext": "Click on chips to bet.",
        "correct_amount": 67,
        "next_question": "end"
    }
}


# For logging visit times
user_log = []

# At top of server.py
user_answers = []

@app.route('/quiz/<quiz_id>', methods=['GET', 'POST'])
def quiz(quiz_id):
    if request.method == 'POST':
        data = request.get_json()
        user_answers.append({
            "question_id": quiz_id,
            "selected": data.get("answer"),
            "correct": data.get("correct")
        })
        return jsonify(status="saved")

    question = quiz_questions.get(quiz_id)
    if not question:
        return "Quiz not found", 404
    return render_template('quiz.html', question=question)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/learn/<lesson_id>')
def learn(lesson_id):
    lesson = lessons.get(lesson_id)
    user_log.append({
        "timestamp": datetime.now().isoformat(),
        "action": f"visited lesson {lesson_id}"
    })
    return render_template('learn.html', lesson=lesson)
@app.route('/pics/<path:filename>')
def pics_file(filename):
    return send_from_directory(os.path.join(app.root_path, 'pics'),
                               filename, conditional=True)

@app.route('/quiz/end')
def quiz_end():
    qids = list(quiz_questions.keys())
    total = len(qids)
    correct = 0
    for qid in qids:
        # collect all answers for this question
        attempts = [a for a in user_answers if a["question_id"] == qid]
        if any(a["correct"] for a in attempts):
            correct += 1

    return render_template('quiz_end.html', correct=correct, total=total)



if __name__ == '__main__':
    reload_opts = {}
    if os.name == "nt":
        reload_opts["use_reloader"] = False
    app.run(host="127.0.0.1", port=5000, debug=True, **reload_opts)
