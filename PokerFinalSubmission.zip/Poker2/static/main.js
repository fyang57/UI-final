$(document).ready(function() {
    $.getJSON("/popular")
        .done(function(speakeasies) {
            let container = $("#popular-speakeasies");
            container.empty();

            speakeasies.forEach(speakeasy => {
                let col = $("<div></div>").addClass("col-md-4 mb-4");

                let card = $("<div></div>").addClass("card h-100");

                let img = $("<img>")
                    .addClass("card-img-top")
                    .attr("src", speakeasy.image)
                    .attr("alt", speakeasy.name)
                    .css("cursor", "pointer")
                    .on("click", function() {
                        window.location.href = `/view/${speakeasy.id}`;
                    });

                let cardBody = $("<div></div>").addClass("card-body");
                let title = $("<h5></h5>").addClass("card-title").text(speakeasy.name);
                let text = $("<p></p>").addClass("card-text").text(speakeasy.summary.substring(0, 100) + "...");
                
                cardBody.append(title, text);
                card.append(img, cardBody);
                col.append(card);
                container.append(col);
            });
        })
        .fail(function() {
            console.error("Error loading popular speakeasies.");
        });

    $("#search-form").on("submit", function(event) {
        let searchInput = $("#search-input");
        let query = searchInput.val().trim(); 

        if (query.length === 0) {  
            event.preventDefault(); 
            searchInput.val("");  
            searchInput.focus();   
            return false;  
        }
    });

    $("input[name='q']").focus();
});
